package com.senai.andre.PrjGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
