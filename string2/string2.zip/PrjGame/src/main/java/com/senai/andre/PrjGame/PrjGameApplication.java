package com.senai.andre.PrjGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjGameApplication {
	public static void main(String[] args) {
		SpringApplication.run(PrjGameApplication.class, args);
	}

}